#!/usr/bin/env python3
"""
Binance Futures Testnet Trading Bot — CLI Entry Point

Usage examples:
  # Market buy
  python cli.py order --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01

  # Limit sell
  python cli.py order --symbol ETHUSDT --side SELL --type LIMIT --quantity 0.1 --price 3500

  # Stop-Market sell
  python cli.py order --symbol BTCUSDT --side SELL --type STOP_MARKET --quantity 0.01 --stop-price 60000

  # Account info
  python cli.py account

  # Open orders
  python cli.py open-orders --symbol BTCUSDT
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Optional

from bot.client import BinanceAPIError, BinanceFuturesClient, BinanceNetworkError
from bot.logging_config import setup_logging
from bot.orders import OrderResult, place_order

# Initialise logging once at import time
setup_logging()


# ─────────────────────────────────────────────────────────────────────────────
# Pretty-print helpers
# ─────────────────────────────────────────────────────────────────────────────

BOLD = "\033[1m"
GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
DIM = "\033[2m"
RESET = "\033[0m"


def _header(text: str) -> None:
    print(f"\n{BOLD}{CYAN}{'─' * 50}{RESET}")
    print(f"{BOLD}{CYAN}  {text}{RESET}")
    print(f"{BOLD}{CYAN}{'─' * 50}{RESET}")


def _row(label: str, value: str, color: str = "") -> None:
    label_w = 22
    print(f"  {DIM}{label:<{label_w}}{RESET}{color}{value}{RESET}")


def print_order_summary(
    symbol: str,
    side: str,
    order_type: str,
    quantity: str,
    price: Optional[str],
    stop_price: Optional[str],
) -> None:
    _header("Order Request Summary")
    _row("Symbol:", symbol, BOLD)
    _row("Side:", side, GREEN if side == "BUY" else RED)
    _row("Type:", order_type)
    _row("Quantity:", quantity)
    if price:
        _row("Price:", price)
    if stop_price:
        _row("Stop Price:", stop_price)
    print()


def print_order_result(result: OrderResult) -> None:
    if result.success:
        _header("✅  Order Placed Successfully")
        _row("Order ID:", str(result.order_id), BOLD)
        _row("Client Order ID:", str(result.client_order_id))
        _row("Symbol:", str(result.symbol))
        _row("Side:", str(result.side), GREEN if result.side == "BUY" else RED)
        _row("Type:", str(result.order_type))
        _row("Status:", str(result.status), GREEN)
        _row("Original Qty:", str(result.orig_qty))
        _row("Executed Qty:", str(result.executed_qty))
        if result.avg_price:
            _row("Avg Fill Price:", result.avg_price)
        if result.price and result.price != "0":
            _row("Limit Price:", result.price)
        if result.time_in_force:
            _row("Time in Force:", result.time_in_force)
        print()
        print(f"  {GREEN}{BOLD}Order submitted to Binance Futures Testnet.{RESET}\n")
    else:
        _header("❌  Order Failed")
        print(f"  {RED}{result.error_message}{RESET}\n")


# ─────────────────────────────────────────────────────────────────────────────
# Sub-command handlers
# ─────────────────────────────────────────────────────────────────────────────

def cmd_order(args: argparse.Namespace, client: BinanceFuturesClient) -> int:
    """Handle the 'order' sub-command."""
    print_order_summary(
        symbol=args.symbol,
        side=args.side.upper(),
        order_type=args.type.upper(),
        quantity=str(args.quantity),
        price=str(args.price) if args.price else None,
        stop_price=str(args.stop_price) if args.stop_price else None,
    )

    result = place_order(
        client=client,
        symbol=args.symbol,
        side=args.side,
        order_type=args.type,
        quantity=args.quantity,
        price=args.price,
        stop_price=args.stop_price,
        time_in_force=args.time_in_force,
    )

    print_order_result(result)
    return 0 if result.success else 1


def cmd_account(args: argparse.Namespace, client: BinanceFuturesClient) -> int:
    """Handle the 'account' sub-command — display key account details."""
    _header("Account Information")
    try:
        info = client.get_account_info()
        assets = [a for a in info.get("assets", []) if float(a.get("walletBalance", 0)) > 0]
        if assets:
            print(f"  {'Asset':<10} {'Wallet Balance':<20} {'Unrealised PnL'}")
            print(f"  {DIM}{'─'*10:<10} {'─'*20:<20} {'─'*15}{RESET}")
            for a in assets:
                print(
                    f"  {BOLD}{a['asset']:<10}{RESET}"
                    f" {a['walletBalance']:<20}"
                    f" {a.get('unrealizedProfit', 'N/A')}"
                )
        else:
            print(f"  {DIM}No funded asset balances found.{RESET}")
        print()
        return 0
    except (BinanceAPIError, BinanceNetworkError) as exc:
        print(f"\n  {RED}Failed to fetch account info: {exc}{RESET}\n")
        return 1


def cmd_open_orders(args: argparse.Namespace, client: BinanceFuturesClient) -> int:
    """Handle the 'open-orders' sub-command."""
    symbol = args.symbol.upper() if args.symbol else None
    _header(f"Open Orders{' — ' + symbol if symbol else ''}")
    try:
        orders = client.get_open_orders(symbol=symbol)
        if not orders:
            print(f"  {DIM}No open orders.{RESET}\n")
        else:
            for o in orders:
                print(
                    f"  {BOLD}#{o['orderId']}{RESET}  "
                    f"{o['symbol']}  "
                    f"{GREEN if o['side']=='BUY' else RED}{o['side']}{RESET}  "
                    f"{o['type']}  qty={o['origQty']}  "
                    f"price={o.get('price','—')}  status={o['status']}"
                )
        print()
        return 0
    except (BinanceAPIError, BinanceNetworkError) as exc:
        print(f"\n  {RED}Failed to fetch open orders: {exc}{RESET}\n")
        return 1


def cmd_ping(args: argparse.Namespace, client: BinanceFuturesClient) -> int:
    """Quick connectivity check."""
    ok = client.ping()
    if ok:
        print(f"\n  {GREEN}✅  Testnet is reachable.{RESET}\n")
        return 0
    else:
        print(f"\n  {RED}❌  Cannot reach testnet.{RESET}\n")
        return 1


# ─────────────────────────────────────────────────────────────────────────────
# Argument parser
# ─────────────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trading_bot",
        description="Binance Futures Testnet Trading Bot",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--api-key",
        default=None,
        help="Binance API key (default: BINANCE_API_KEY env var)",
    )
    parser.add_argument(
        "--api-secret",
        default=None,
        help="Binance API secret (default: BINANCE_API_SECRET env var)",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging verbosity (default: INFO)",
    )

    sub = parser.add_subparsers(dest="command", metavar="COMMAND", required=True)

    # ── order ──────────────────────────────────────────────────────────────
    order_p = sub.add_parser("order", help="Place a new futures order")
    order_p.add_argument(
        "--symbol", "-s", required=True,
        help="Trading pair, e.g. BTCUSDT",
    )
    order_p.add_argument(
        "--side", required=True,
        choices=["BUY", "SELL", "buy", "sell"],
        help="Order side: BUY or SELL",
    )
    order_p.add_argument(
        "--type", "-t", required=True,
        dest="type",
        choices=["MARKET", "LIMIT", "STOP_MARKET", "market", "limit", "stop_market"],
        help="Order type: MARKET | LIMIT | STOP_MARKET",
    )
    order_p.add_argument(
        "--quantity", "-q", required=True, type=float,
        help="Order quantity (in base asset units)",
    )
    order_p.add_argument(
        "--price", "-p", type=float, default=None,
        help="Limit price (required for LIMIT orders)",
    )
    order_p.add_argument(
        "--stop-price", type=float, default=None,
        help="Stop trigger price (required for STOP_MARKET orders)",
    )
    order_p.add_argument(
        "--time-in-force", default="GTC",
        choices=["GTC", "IOC", "FOK"],
        help="Time in force for LIMIT orders (default: GTC)",
    )

    # ── account ────────────────────────────────────────────────────────────
    sub.add_parser("account", help="Show account balances")

    # ── open-orders ────────────────────────────────────────────────────────
    oo_p = sub.add_parser("open-orders", help="List open orders")
    oo_p.add_argument("--symbol", "-s", default=None, help="Filter by symbol")

    # ── ping ───────────────────────────────────────────────────────────────
    sub.add_parser("ping", help="Test connectivity to the testnet")

    return parser


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    setup_logging(args.log_level)

    try:
        client = BinanceFuturesClient(
            api_key=args.api_key,
            api_secret=args.api_secret,
        )
    except ValueError as exc:
        print(f"\n  {RED}Configuration error: {exc}{RESET}\n")
        return 2

    dispatch = {
        "order": cmd_order,
        "account": cmd_account,
        "open-orders": cmd_open_orders,
        "ping": cmd_ping,
    }

    handler = dispatch.get(args.command)
    if handler is None:
        parser.print_help()
        return 1

    return handler(args, client)


if __name__ == "__main__":
    sys.exit(main())
