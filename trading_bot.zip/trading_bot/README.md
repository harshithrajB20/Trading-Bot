# Binance Futures Testnet Trading Bot

A clean, structured Python CLI for placing orders on [Binance USDT-M Futures Testnet](https://testnet.binancefuture.com).

Supports **Market**, **Limit**, and **Stop-Market** orders with full input validation, structured logging, and thorough error handling.

---

## Project Structure

```
trading_bot/
├── bot/
│   ├── __init__.py
│   ├── client.py          # Binance Futures REST client (direct HTTP, no SDK)
│   ├── orders.py          # Order placement logic + OrderResult dataclass
│   ├── validators.py      # Input validation (symbol, side, type, qty, price)
│   └── logging_config.py  # Rotating file + console logging setup
├── cli.py                 # CLI entry point (argparse)
├── logs/
│   └── trading_bot.log    # Auto-created on first run
├── requirements.txt
└── README.md
```

---

## Setup

### 1. Python version

Requires **Python 3.9+**.

### 2. Get Testnet credentials

1. Visit <https://testnet.binancefuture.com>
2. Log in (or register) and navigate to **API Management**
3. Create an API key — save both the **API Key** and **Secret Key**

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

Only one dependency: `requests`.

### 4. Set environment variables

```bash
export BINANCE_API_KEY="your_api_key_here"
export BINANCE_API_SECRET="your_api_secret_here"
```

Or pass them per-command with `--api-key` / `--api-secret`.

---

## How to Run

All commands follow this structure:

```
python cli.py [--api-key KEY] [--api-secret SECRET] [--log-level LEVEL] COMMAND [options]
```

---

### Test connectivity

```bash
python cli.py ping
```

---

### Place a MARKET order

```bash
# Buy 0.01 BTC at market price
python cli.py order --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01

# Sell 0.1 ETH at market price
python cli.py order --symbol ETHUSDT --side SELL --type MARKET --quantity 0.1
```

**Example output:**
```
──────────────────────────────────────────────────
  Order Request Summary
──────────────────────────────────────────────────
  Symbol:                BTCUSDT
  Side:                  BUY
  Type:                  MARKET
  Quantity:              0.01

──────────────────────────────────────────────────
  ✅  Order Placed Successfully
──────────────────────────────────────────────────
  Order ID:              3951823
  Client Order ID:       web_yQGpPxrV3pNa7bX5
  Symbol:                BTCUSDT
  Side:                  BUY
  Type:                  MARKET
  Status:                FILLED
  Original Qty:          0.01
  Executed Qty:          0.01
  Avg Fill Price:        67423.50

  Order submitted to Binance Futures Testnet.
```

---

### Place a LIMIT order

```bash
# Sell 0.01 BTC at $70,000 (resting limit)
python cli.py order --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.01 --price 70000

# Buy 0.5 ETH with IOC time-in-force
python cli.py order --symbol ETHUSDT --side BUY --type LIMIT \
    --quantity 0.5 --price 3000 --time-in-force IOC
```

---

### Place a STOP_MARKET order *(bonus order type)*

Triggers a market order when the price hits `--stop-price`.

```bash
# Protective stop: sell 0.01 BTC if price drops to $60,000
python cli.py order --symbol BTCUSDT --side SELL --type STOP_MARKET \
    --quantity 0.01 --stop-price 60000
```

---

### View account balances

```bash
python cli.py account
```

---

### View open orders

```bash
# All open orders
python cli.py open-orders

# Filter by symbol
python cli.py open-orders --symbol BTCUSDT
```

---

## Logging

Logs are written to `logs/trading_bot.log` (auto-created).

- **File log**: `DEBUG` level — includes all API request params, raw responses, errors, and validation warnings.
- **Console**: `WARNING+` only — keeps CLI output clean.
- Log files rotate at **5 MB** with 5 backups retained.

Sample log entries are included in `logs/trading_bot.log`.

---

## Error Handling

| Scenario | Behaviour |
|---|---|
| Missing/invalid symbol, side, type | Clear message, no API call made |
| Price missing for LIMIT order | Validation error before request |
| Quantity out of range | Validation error before request |
| Binance API error (e.g. insufficient margin) | Error message with Binance code + reason |
| Network timeout / connection failure | Friendly error; no crash |
| Missing API credentials | Startup error with instructions |

---

## Assumptions

- **Testnet only** — the base URL is hardcoded to `https://testnet.binancefuture.com`. Swap in `client.py` for production.
- **USDT-M Futures** only (linear contracts).
- Quantity precision follows your input; Binance may reject if it doesn't match the symbol's `stepSize` — check Exchange Info if you get `-1111` errors.
- `STOP_MARKET` uses `workingType=CONTRACT_PRICE` (the default). Pass additional params via the client directly for `MARK_PRICE` stops.
- No order persistence — all state lives in Binance's system; query with `open-orders` or `order` endpoints.
