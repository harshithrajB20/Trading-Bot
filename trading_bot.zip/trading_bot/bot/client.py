"""
Binance Futures Testnet REST client.

Uses direct HTTP calls (requests) — no third-party Binance SDK required.
Handles HMAC-SHA256 request signing, timestamp management, and HTTP errors.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import time
import urllib.parse
from typing import Any, Dict, Optional

import requests

from bot.logging_config import get_logger

logger = get_logger("client")

TESTNET_BASE_URL = "https://testnet.binancefuture.com"
DEFAULT_TIMEOUT = 10  # seconds


class BinanceAPIError(Exception):
    """Raised when the Binance API returns an error payload."""

    def __init__(self, code: int, msg: str, status_code: int = 0):
        self.code = code
        self.msg = msg
        self.status_code = status_code
        super().__init__(f"Binance API error {code}: {msg}")


class BinanceNetworkError(Exception):
    """Raised on connection / timeout failures."""


class BinanceFuturesClient:
    """
    Thin wrapper around the Binance USDT-M Futures REST API.

    Parameters
    ----------
    api_key:    Read from env var BINANCE_API_KEY if not provided.
    api_secret: Read from env var BINANCE_API_SECRET if not provided.
    base_url:   Override for testing; defaults to the testnet URL.
    timeout:    HTTP timeout in seconds.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        api_secret: Optional[str] = None,
        base_url: str = TESTNET_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
    ):
        self.api_key = api_key or os.environ.get("BINANCE_API_KEY", "")
        self.api_secret = api_secret or os.environ.get("BINANCE_API_SECRET", "")
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

        if not self.api_key or not self.api_secret:
            raise ValueError(
                "Binance API key and secret are required. "
                "Set BINANCE_API_KEY and BINANCE_API_SECRET environment variables, "
                "or pass them explicitly."
            )

        self._session = requests.Session()
        self._session.headers.update(
            {
                "X-MBX-APIKEY": self.api_key,
                "Content-Type": "application/x-www-form-urlencoded",
            }
        )
        logger.info("BinanceFuturesClient initialised (base_url=%s)", self.base_url)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _timestamp() -> int:
        return int(time.time() * 1000)

    def _sign(self, params: Dict[str, Any]) -> str:
        """Return HMAC-SHA256 signature for the given query-string params."""
        query_string = urllib.parse.urlencode(params)
        return hmac.new(
            self.api_secret.encode("utf-8"),
            query_string.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

    def _request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        signed: bool = False,
    ) -> Any:
        """
        Low-level HTTP request dispatcher.

        Adds timestamp + signature for signed endpoints.
        Raises BinanceAPIError or BinanceNetworkError on failure.
        """
        params = params or {}

        if signed:
            params["timestamp"] = self._timestamp()
            params["signature"] = self._sign(params)

        url = f"{self.base_url}{path}"
        logger.debug(
            "→ %s %s | params=%s",
            method.upper(),
            path,
            {k: v for k, v in params.items() if k != "signature"},
        )

        try:
            if method.upper() == "GET":
                resp = self._session.get(url, params=params, timeout=self.timeout)
            elif method.upper() == "POST":
                resp = self._session.post(url, data=params, timeout=self.timeout)
            elif method.upper() == "DELETE":
                resp = self._session.delete(url, params=params, timeout=self.timeout)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
        except requests.exceptions.Timeout as exc:
            logger.error("Request timed out: %s %s", method, path)
            raise BinanceNetworkError(f"Request timed out ({self.timeout}s): {exc}") from exc
        except requests.exceptions.ConnectionError as exc:
            logger.error("Connection error: %s %s — %s", method, path, exc)
            raise BinanceNetworkError(f"Connection error: {exc}") from exc

        logger.debug("← HTTP %s | body=%s", resp.status_code, resp.text[:500])

        try:
            data = resp.json()
        except ValueError:
            resp.raise_for_status()
            return resp.text

        if isinstance(data, dict) and "code" in data and data["code"] != 200:
            # Binance uses negative codes for errors
            if data["code"] < 0:
                logger.error(
                    "API error: code=%s msg=%s", data.get("code"), data.get("msg")
                )
                raise BinanceAPIError(
                    code=data["code"],
                    msg=data.get("msg", "Unknown error"),
                    status_code=resp.status_code,
                )

        if not resp.ok:
            resp.raise_for_status()

        return data

    # ------------------------------------------------------------------
    # Public API methods
    # ------------------------------------------------------------------

    def ping(self) -> bool:
        """Return True if the API endpoint is reachable."""
        try:
            self._request("GET", "/fapi/v1/ping")
            logger.info("Ping successful")
            return True
        except Exception as exc:
            logger.warning("Ping failed: %s", exc)
            return False

    def get_server_time(self) -> int:
        """Return server timestamp in milliseconds."""
        data = self._request("GET", "/fapi/v1/time")
        return data["serverTime"]

    def get_account_info(self) -> Dict[str, Any]:
        """Return futures account information (requires signed request)."""
        return self._request("GET", "/fapi/v2/account", signed=True)

    def get_exchange_info(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        """Return exchange info, optionally filtered to one symbol."""
        params = {}
        if symbol:
            params["symbol"] = symbol.upper()
        return self._request("GET", "/fapi/v1/exchangeInfo", params=params)

    def place_order(self, **kwargs) -> Dict[str, Any]:
        """
        Place a futures order.

        Common kwargs: symbol, side, type, quantity, price,
                       timeInForce, stopPrice, reduceOnly, newClientOrderId.
        """
        # Remove None values — Binance rejects unexpected null params
        params = {k.upper() if k == "type" else k: v for k, v in kwargs.items() if v is not None}
        # Binance param name is uppercase TYPE but we keep camelCase for others
        # Actually Binance uses camelCase for body params:
        params = {k: v for k, v in kwargs.items() if v is not None}

        logger.info(
            "Placing order: symbol=%s side=%s type=%s qty=%s price=%s",
            params.get("symbol"),
            params.get("side"),
            params.get("type"),
            params.get("quantity"),
            params.get("price", "MARKET"),
        )

        result = self._request("POST", "/fapi/v1/order", params=params, signed=True)
        logger.info(
            "Order placed: orderId=%s status=%s executedQty=%s",
            result.get("orderId"),
            result.get("status"),
            result.get("executedQty"),
        )
        return result

    def cancel_order(self, symbol: str, order_id: int) -> Dict[str, Any]:
        """Cancel an open order by ID."""
        params = {"symbol": symbol.upper(), "orderId": order_id}
        return self._request("DELETE", "/fapi/v1/order", params=params, signed=True)

    def get_order(self, symbol: str, order_id: int) -> Dict[str, Any]:
        """Query a single order by ID."""
        params = {"symbol": symbol.upper(), "orderId": order_id}
        return self._request("GET", "/fapi/v1/order", params=params, signed=True)

    def get_open_orders(self, symbol: Optional[str] = None) -> list:
        """Return all open orders, optionally filtered by symbol."""
        params = {}
        if symbol:
            params["symbol"] = symbol.upper()
        return self._request("GET", "/fapi/v1/openOrders", params=params, signed=True)

    def get_position_risk(self, symbol: Optional[str] = None) -> list:
        """Return current position info."""
        params = {}
        if symbol:
            params["symbol"] = symbol.upper()
        return self._request("GET", "/fapi/v2/positionRisk", params=params, signed=True)
