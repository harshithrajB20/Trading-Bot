"""
Order placement logic — sits between the CLI layer and the Binance client.

Each public function validates inputs, delegates to the client, and returns
a clean OrderResult dataclass ready for display.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Dict, Optional

from bot.client import BinanceFuturesClient
from bot.logging_config import get_logger
from bot.validators import (
    validate_order_type,
    validate_price,
    validate_quantity,
    validate_side,
    validate_stop_price,
    validate_symbol,
)

logger = get_logger("orders")


@dataclass
class OrderResult:
    """Structured representation of a placed order response."""

    success: bool
    order_id: Optional[int] = None
    client_order_id: Optional[str] = None
    symbol: Optional[str] = None
    side: Optional[str] = None
    order_type: Optional[str] = None
    status: Optional[str] = None
    orig_qty: Optional[str] = None
    executed_qty: Optional[str] = None
    avg_price: Optional[str] = None
    price: Optional[str] = None
    time_in_force: Optional[str] = None
    raw_response: Dict[str, Any] = field(default_factory=dict)
    error_message: Optional[str] = None

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "OrderResult":
        avg = data.get("avgPrice") or data.get("averagePrice") or "0"
        return cls(
            success=True,
            order_id=data.get("orderId"),
            client_order_id=data.get("clientOrderId"),
            symbol=data.get("symbol"),
            side=data.get("side"),
            order_type=data.get("type"),
            status=data.get("status"),
            orig_qty=data.get("origQty"),
            executed_qty=data.get("executedQty"),
            avg_price=avg if avg != "0" else None,
            price=data.get("price"),
            time_in_force=data.get("timeInForce"),
            raw_response=data,
        )

    @classmethod
    def from_error(cls, message: str) -> "OrderResult":
        return cls(success=False, error_message=message)


def place_order(
    client: BinanceFuturesClient,
    symbol: str,
    side: str,
    order_type: str,
    quantity: str | float,
    price: Optional[str | float] = None,
    stop_price: Optional[str | float] = None,
    time_in_force: str = "GTC",
) -> OrderResult:
    """
    Validate all inputs and place an order on Binance Futures.

    Supports: MARKET, LIMIT, STOP_MARKET.
    Returns an OrderResult regardless of success/failure.
    """
    # --- validate ---
    try:
        symbol = validate_symbol(symbol)
        side = validate_side(side)
        order_type = validate_order_type(order_type)
        qty = validate_quantity(quantity)
        validated_price = validate_price(price, order_type)
        validated_stop = validate_stop_price(stop_price, order_type)
    except ValueError as exc:
        logger.warning("Validation failed: %s", exc)
        return OrderResult.from_error(str(exc))

    # --- build request params ---
    params: Dict[str, Any] = {
        "symbol": symbol,
        "side": side,
        "type": order_type,
        "quantity": str(qty),
    }

    if order_type == "LIMIT":
        params["price"] = str(validated_price)
        params["timeInForce"] = time_in_force

    if order_type == "STOP_MARKET":
        params["stopPrice"] = str(validated_stop)

    logger.debug("Prepared order params: %s", params)

    # --- place ---
    try:
        response = client.place_order(**params)
        result = OrderResult.from_api_response(response)
        logger.info(
            "Order success: orderId=%s symbol=%s side=%s type=%s status=%s",
            result.order_id,
            result.symbol,
            result.side,
            result.order_type,
            result.status,
        )
        return result
    except Exception as exc:
        logger.error("Order failed: %s", exc, exc_info=True)
        return OrderResult.from_error(str(exc))
