"""
Input validation for trading bot CLI parameters.
All validators raise ValueError with human-readable messages on bad input.
"""

from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Optional


VALID_SIDES = {"BUY", "SELL"}
VALID_ORDER_TYPES = {"MARKET", "LIMIT", "STOP_MARKET"}

# Conservative limits — the testnet accepts much wider ranges,
# but these guard against obvious typos.
MIN_QUANTITY = Decimal("0.001")
MAX_QUANTITY = Decimal("1_000_000")
MIN_PRICE = Decimal("0.01")
MAX_PRICE = Decimal("10_000_000")


def validate_symbol(symbol: str) -> str:
    """Return uppercased symbol or raise ValueError."""
    symbol = symbol.strip().upper()
    if not symbol.isalnum():
        raise ValueError(
            f"Symbol '{symbol}' is invalid — use alphanumeric characters only (e.g. BTCUSDT)."
        )
    if len(symbol) < 3 or len(symbol) > 20:
        raise ValueError(
            f"Symbol '{symbol}' looks wrong — expected 3–20 characters (e.g. BTCUSDT)."
        )
    return symbol


def validate_side(side: str) -> str:
    """Return uppercased side or raise ValueError."""
    side = side.strip().upper()
    if side not in VALID_SIDES:
        raise ValueError(
            f"Side '{side}' is not valid. Choose from: {', '.join(sorted(VALID_SIDES))}."
        )
    return side


def validate_order_type(order_type: str) -> str:
    """Return uppercased order type or raise ValueError."""
    order_type = order_type.strip().upper()
    if order_type not in VALID_ORDER_TYPES:
        raise ValueError(
            f"Order type '{order_type}' is not valid. "
            f"Choose from: {', '.join(sorted(VALID_ORDER_TYPES))}."
        )
    return order_type


def validate_quantity(quantity: str | float) -> Decimal:
    """Parse and validate quantity. Returns a Decimal."""
    try:
        qty = Decimal(str(quantity))
    except InvalidOperation:
        raise ValueError(f"Quantity '{quantity}' is not a valid number.")

    if qty <= 0:
        raise ValueError(f"Quantity must be positive, got {qty}.")
    if qty < MIN_QUANTITY:
        raise ValueError(f"Quantity {qty} is below the minimum allowed ({MIN_QUANTITY}).")
    if qty > MAX_QUANTITY:
        raise ValueError(f"Quantity {qty} exceeds the maximum allowed ({MAX_QUANTITY}).")

    return qty


def validate_price(price: str | float | None, order_type: str) -> Optional[Decimal]:
    """
    Validate price for LIMIT / STOP_MARKET orders.
    Returns None for MARKET orders (price not required).
    Raises ValueError if price is missing when required, or out of range.
    """
    order_type = order_type.upper()

    if order_type == "MARKET":
        if price is not None:
            # Warn but don't fail — we'll just ignore it.
            pass
        return None

    # LIMIT and STOP_MARKET require a price
    if price is None:
        raise ValueError(
            f"A price is required for {order_type} orders. Pass --price <value>."
        )

    try:
        p = Decimal(str(price))
    except InvalidOperation:
        raise ValueError(f"Price '{price}' is not a valid number.")

    if p <= 0:
        raise ValueError(f"Price must be positive, got {p}.")
    if p < MIN_PRICE:
        raise ValueError(f"Price {p} is below the minimum allowed ({MIN_PRICE}).")
    if p > MAX_PRICE:
        raise ValueError(f"Price {p} exceeds the maximum allowed ({MAX_PRICE}).")

    return p


def validate_stop_price(stop_price: str | float | None, order_type: str) -> Optional[Decimal]:
    """Validate stop_price for STOP_MARKET orders."""
    if order_type.upper() != "STOP_MARKET":
        return None

    if stop_price is None:
        raise ValueError("A stop_price is required for STOP_MARKET orders. Pass --stop-price <value>.")

    try:
        sp = Decimal(str(stop_price))
    except InvalidOperation:
        raise ValueError(f"Stop price '{stop_price}' is not a valid number.")

    if sp <= 0:
        raise ValueError(f"Stop price must be positive, got {sp}.")

    return sp
